# dotUniverse - Fullstack Application

A clean, production-ready fullstack architecture featuring a **Next.js** frontend and a **Node.js + Express + MongoDB** backend.

---

## 📁 Project Structure

```text
dotUniverse/
├── backend/
│   ├── src/
│   │   ├── config/
│   │   │   └── db.js              # MongoDB Mongoose connection
│   │   ├── controllers/
│   │   │   └── userController.js  # Request handlers / business logic
│   │   ├── middlewares/
│   │   │   └── errorHandler.js    # Centralized API error handling
│   │   ├── models/
│   │   │   └── userModel.js       # Mongoose schemas & data models
│   │   ├── routes/
│   │   │   └── userRoutes.js      # REST API route declarations
│   │   ├── app.js                 # Express application configuration
│   │   └── server.js              # HTTP server & database bootstrapper
│   ├── .env.example               # Example environment variables
│   ├── .env                       # Local environment variables
│   ├── .gitignore                 # Backend-specific ignore list
│   └── package.json               # Backend dependencies and scripts
│
├── frontend/
│   ├── src/
│   │   └── app/
│   │       ├── favicon.ico
│   │       ├── globals.css        # Global CSS styling
│   │       ├── layout.tsx         # Root Next.js layout
│   │       └── page.tsx           # Landing page
│   ├── public/                    # Static assets
│   ├── .gitignore                 # Frontend-specific ignore list
│   ├── next.config.ts             # Next.js configuration
│   ├── package.json               # Frontend dependencies and scripts
│   └── tsconfig.json              # TypeScript configuration
│
├── .gitignore                     # Workspace root gitignore
├── package.json                   # Root orchestrator scripts
└── README.md                      # Documentation
```

---

## 🚀 Getting Started

### 1. Prerequisites
- **Node.js** (v18+ recommended)
- **MongoDB** running locally or via MongoDB Atlas connection string

### 2. Environment Variables

Create and verify `backend/.env`:

```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/dotuniverse
NODE_ENV=development
CLIENT_URL=http://localhost:3000
```

### 3. Installation

Install dependencies for both projects from the root:
```bash
npm run install:all
```
*(Or navigate to `backend` and `frontend` folders individually and run `npm install`)*

---

## 🏃 Running the Application

### Backend (Express + MongoDB)
```bash
# From workspace root:
npm run backend:dev

# Or inside backend/:
cd backend
npm run dev
```
- API Base URL: `http://localhost:5000`
- Health Check: `http://localhost:5000/api/health`
- Users Endpoint: `http://localhost:5000/api/users`

### Frontend (Next.js)
```bash
# From workspace root:
npm run frontend:dev

# Or inside frontend/:
cd frontend
npm run dev
```
- Web Application URL: `http://localhost:3000`

---

## 🛠 API Endpoints Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/health` | Service health status check |
| `GET` | `/api/users` | List all users |
| `POST` | `/api/users` | Create a new user (`{ name, email, role? }`) |
| `GET` | `/api/users/:id` | Fetch user by MongoDB ObjectId |
